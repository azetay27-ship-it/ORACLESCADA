"""Oracle HTTP routers."""
